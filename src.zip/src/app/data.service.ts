import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private _http: HttpClient) { }
  // some dummy data
  getUsers(){
    return this._http.get('https://reqres.in/api/users')
  }
}
